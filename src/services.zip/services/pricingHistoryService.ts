const STORAGE_KEY = "pricingHistory";

export const pricingHistoryService = {
  getAll() {
    const data = localStorage.getItem(STORAGE_KEY);

    return data ? JSON.parse(data) : [];
  },

  saveAll(history: any[]) {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(history)
    );
  },
};
const express = require("express");

const router = express.Router();

const authMiddleware =
  require("../../middlewares/authMiddleware");

const checkFeature =
  require("../../middlewares/checkFeature");

const {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
} = require("./product.controller");

router.post(
  "/",
  authMiddleware,
  checkFeature(
    "Product Master Management"
  ),
  createProduct
);

router.get(
  "/",
  authMiddleware,
  checkFeature(
    "Product Master Management"
  ),
  getProducts
);

router.get(
  "/:id",
  authMiddleware,
  checkFeature(
    "Product Master Management"
  ),
  getProductById
);

router.put(
  "/:id",
  authMiddleware,
  checkFeature(
    "Product Master Management"
  ),
  updateProduct
);

router.delete(
  "/:id",
  authMiddleware,
  checkFeature(
    "Product Master Management"
  ),
  deleteProduct
);

module.exports = router;
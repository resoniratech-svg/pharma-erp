const productService = require(
  "./product.service"
);

const createProduct = async (
  req,
  res
) => {
  try {

    const product =
      await productService.createProductService(
        req.body
      );

    res.status(201).json({
      success: true,
      data: product,
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message,
    });

  }
};

const getProducts = async (
  req,
  res
) => {
  try {

    const products =
      await productService.getProductsService();

    res.status(200).json({
      success: true,
      data: products,
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message,
    });

  }
};

const getProductById = async (
  req,
  res
) => {
  try {

    const product =
      await productService.getProductById(
        Number(req.params.id)
      );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    res.status(200).json({
      success: true,
      data: product,
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message,
    });

  }
};

const updateProduct = async (
  req,
  res
) => {
  try {

    const product =
      await productService.updateProduct(
        Number(req.params.id),
        req.body
      );

    res.status(200).json({
      success: true,
      data: product,
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message,
    });

  }
};

const deleteProduct = async (
  req,
  res
) => {
  try {

    const product =
      await productService.getProductById(
        Number(req.params.id)
      );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    await productService.deleteProduct(
      Number(req.params.id)
    );

    res.status(200).json({
      success: true,
      message:
        "Product deleted successfully",
    });

  } catch (error) {

    res.status(400).json({
      success: false,
      message: error.message,
    });

  }
};

module.exports = {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};